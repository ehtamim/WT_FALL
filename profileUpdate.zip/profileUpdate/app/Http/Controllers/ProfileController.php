<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\UserModel;
use Illuminate\Support\Facades\Input;

class ProfileController extends Controller
{
    function profileView(){
        $usertable=new UserModel();
        if (session()->has('id')) 
        {
            $uid=session()->get('id');
            //$users=$usertable->get();
            /*foreach($users as $user)
            {
                if ($user->id==$uid)
                {
                    $uname=$user->name;
                    $ucontact=$user->contact;
                    $uemail=$user->email;
                    $upassword=$user->password;
                    return view("profile")->with("uname",$uname)
            ->with("uid",$uid);
            ->with("ucontact",$ucontact)
            ->with("uemail",$uemail)
            ->with("upassword",$upassword);

                }
            }*/
            $employee=$usertable->where('id',$uid);
            //return view("profile")->with("employee",$employee);

            if(!empty($employee))
            {
            $name=$usertable->where('id',$uid)->pluck('name');
            foreach($name as $n)
            {
                $uname=$n;
            }
            $contact=$usertable->where('id',$uid)->pluck('contact');
            foreach($contact as $c)
            {
                $ucontact=$c;
            }
            $email=$usertable->where('id',$uid)->pluck('email');
            foreach($email as $e)
            {
                $uemail=$e;
            }
            $password=$usertable->where('id',$uid)->pluck('password');
            foreach($password as $p)
            {
                $upassword=$p;
            }
            return view("profile")->with("uname",$uname)
            ->with("uid",$uid)
            ->with("ucontact",$ucontact)
            ->with("uemail",$uemail)
            ->with("upassword",$upassword);
            }
            else
            {
            $output="Wrong Info";
            return $output;
            }
        }
}
function profileUpdate(Request $request)
{
    $this->validate($request,
    [ '$name'=>'required|min:6',
      '$contact'=>'required|max:14|min:11',
      '$email'=>'regex:/(.+)@(.+)\.(.+)/i',
      '$password'=>'min:4',
    ]);
 if (isset($error))
 {
 $output="<h1>Submitted</h1>";
 $output.="udname: ".$request->udname;
 $output.="<br>udcontact: ".$request->udcontact;
 $output.="<br>udemail: ".$request->udemail;
 $output.="<br>udpassword: ".$request->udpassword;
 return $output;
 }
 else{
     $udname=$request->udname;
     $udcontact=$request->get('udcontact');
     $udemail=$email = $request->get('udemail');
     $udpassword=$request->get('udpassword');
     $uid=session()->get('id');
     $usetable=new UserModel();
     $update=$usetable->where('id',$uid)->update(['name'=>$udname])->update(['contact'=>$udcontact])->update(['email'=>$udemail])->update(['password'=>$udpassword]);
     /*$update->name=$request->udname;
     $update->contact=$request->udcontact;
     $update->email=$request->udemail;
     $update->password=$request->udpassword;
     $usetable->save();
     /*return view("profile")->with("udname",$udname)
            ->with("udcontact",$udcontact)
            ->with("udemail",$udemail)
            ->with("udpassword",$udpassword);*/
}
}
}
?>